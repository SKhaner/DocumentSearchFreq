# project5 - Due December 10th midnight
Submit your project5 in your repo. 
The project description is specified in Project5.pdf. Go through the project description and the specifications very carefully. Your final submission must meet <b> all </b> specifications in order to earn any credit.
Sample data files are placed in p5docs directory. However, we strongly recommend that you test your search engine on different test files.
You are allowed to use any/all of your Homework 6 hashmap code.
(Complete this project before the due date since your final project is due on the final exam date - Dec.15th)
